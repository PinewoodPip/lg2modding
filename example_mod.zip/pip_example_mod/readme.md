
This is an example mod for Lazy Galaxy 2 !

It shows off what can be done with the mod support with a few examples. It's ***not*** a mod meant to be actually played with! 

You can read up the documentation for the modding support here: https://www.pinewood.team/lg2modding/

To take a look at how things in this mod are implemented, download the source here: https://www.pinewood.team/lg2modding/example_mod.zip

This example mod features:

- A short custom campaign (you can open it in the map editor)
- 2 custom ships:
    - Whale: a slow tanky ship that can summon (summon_ability.json) and shoot in a spiral (spiral_ability.json) and can heal+shield ships with its active ability (healing_ability.json)
    - Falcon: a fast ship that shoots bullets in a cone (pellet_blast_ability.json) and can throw a grenade that spews more bullets around it (bullet_sprinkler_starter.json, see flurry ability type documentation)
- 2 upgrades: one unlocks the 2 ships from the mod, the other one buffs them. Available in tiers 2 and 3.
- A food item with a ridiculously high chance of appearing in lunchboxes that boosts solar panels and gives production bonus per planet conquered
- A new advanced recipe